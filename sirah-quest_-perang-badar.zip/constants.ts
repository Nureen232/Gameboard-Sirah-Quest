
import { QuizDatabase, QuestData } from './types';

export const STREAK_BADGE_THRESHOLD = 5;
export const PLAYER_CHARACTERS = ['👳‍♂️', '🧕'];

const badarQuizDatabase: QuizDatabase = {
    1: { question: "Apakah nama peperangan ini?", options: ["Perang Uhud", "Perang Khandaq", "Perang Badar", "Perang Tabuk"], correct: 2, explanation: "Peperangan agung ini dikenali sebagai Perang Badar, yang berlaku pada tahun ke-2 Hijrah." },
    2: { question: "Di manakah Nabi Muhammad SAW berhijrah sebelum perang ini?", options: ["Mekah", "Madinah", "Taif", "Habsyah"], correct: 1, explanation: "Nabi Muhammad SAW berhijrah ke Madinah, yang menjadi pangkalan utama umat Islam." },
    3: { question: "Siapakah musuh utama umat Islam dalam perang ini?", options: ["Orang Rom", "Orang Parsi", "Orang Yahudi Madinah", "Orang kafir Quraisy"], correct: 3, explanation: "Musuh utama adalah kaum kafir Quraisy dari Mekah yang menentang dakwah Islam." },
    4: { question: "Mengapa Nabi SAW sentiasa berjaga pada waktu malam di Madinah?", options: ["Menunggu wahyu", "Ancaman orang Quraisy", "Menyusun strategi", "Beribadah sunat"], correct: 1, explanation: "Kerana ancaman serangan hendap daripada pihak Quraisy yang sentiasa memusuhi Islam." },
    5: { question: "Siapakah yang mengawal Nabi SAW pada waktu malam?", options: ["Para malaikat", "Tentera upahan", "Para sahabat", "Keluarga baginda"], correct: 2, explanation: "Para sahabat yang setia bergilir-gilir mengawal keselamatan Rasulullah SAW." },
    6: { question: "Perang Badar berlaku pada bulan apa?", options: ["Syawal", "Zulkaedah", "Ramadan", "Muharram"], correct: 2, explanation: "Perang Badar berlaku dalam bulan Ramadan, bulan yang penuh keberkatan." },
    7: { question: "Tahun ke berapakah Hijrah perang ini berlaku?", options: ["Tahun pertama", "Tahun ke-2", "Tahun ke-3", "Tahun ke-5"], correct: 1, explanation: "Peristiwa penting ini berlaku pada tahun ke-2 selepas Hijrah Nabi SAW ke Madinah." },
    8: { question: "Berapa jumlah tentera Islam?", options: ["313 orang", "500 orang", "700 orang", "1000 orang"], correct: 0, explanation: "Tentera Islam hanya seramai 313 orang, menunjukkan betapa kecilnya jumlah mereka berbanding musuh." },
    9: { question: "Berapa ekor kuda perang tentera Islam?", options: ["20 ekor", "10 ekor", "50 ekor", "2 ekor"], correct: 3, explanation: "Dengan serba kekurangan, tentera Islam hanya memiliki 2 ekor kuda." },
    10: { question: "Berapa ekor unta digunakan sebagai tunggangan?", options: ["70 ekor", "100 ekor", "150 ekor", "200 ekor"], correct: 0, explanation: "Sebanyak 70 ekor unta dikongsi secara bergilir-gilir oleh para tentera Islam." },
    11: { question: "Apakah tujuan ASAL tentera Islam keluar dari Madinah?", options: ["Menyerang Mekah", "Mencari kawasan baru", "Menyekat rombongan dagang Quraisy", "Berperang dengan Abu Jahal"], correct: 2, explanation: "Tujuan asalnya adalah untuk menyekat rombongan dagang Quraisy yang dipimpin oleh Abu Sufyan." },
    12: { question: "Siapakah ketua rombongan dagang Quraisy?", options: ["Abu Jahal", "Abu Lahab", "Umayyah bin Khalaf", "Abu Sufyan"], correct: 3, explanation: "Abu Sufyan adalah ketua rombongan dagang Quraisy yang kaya dari Syam." },
    13: { question: "Mengapa harta dagangan tersebut ingin diambil semula?", options: ["Sebagai rampasan perang", "Kerana dirampas semasa hijrah", "Untuk memulakan perniagaan", "Sebagai cukai"], correct: 1, explanation: "Ia sebagai ganti kepada harta umat Islam yang telah dirampas oleh kaum Quraisy semasa mereka berhijrah." },
    14: { question: "Siapakah yang mengetahui pergerakan tentera Islam?", options: ["Abu Jahal", "Seorang pengintip", "Abu Sufyan", "Penduduk Badar"], correct: 2, explanation: "Abu Sufyan, dengan kebijaksanaannya, dapat mengesan pergerakan tentera Islam." },
    15: { question: "Siapakah yang diminta bantuan oleh Abu Sufyan?", options: ["Bani Hasyim", "Penduduk Taif", "Orang Rom", "Abu Jahal"], correct: 3, explanation: "Abu Sufyan menghantar utusan untuk meminta bantuan ketenteraan dari Mekah, yang dipimpin oleh Abu Jahal." },
    16: { question: "Dari manakah Abu Jahal memimpin tentera?", options: ["Taif", "Madinah", "Syam", "Mekah"], correct: 3, explanation: "Abu Jahal dengan sombongnya memimpin bala tentera kafir Quraisy dari Mekah." },
    17: { question: "Berapa jumlah tentera musyrikin?", options: ["500 orang", "750 orang", "1000 orang", "1300 orang"], correct: 2, explanation: "Tentera musyrikin berjumlah sekitar 1000 orang, tiga kali ganda lebih ramai dari tentera Islam." },
    18: { question: "Di manakah tentera Islam dan musyrikin bertemu?", options: ["Di Uhud", "Di Khandaq", "Di Badar", "Di luar kota Mekah"], correct: 2, explanation: "Pertembungan yang tidak dirancang ini berlaku di sebuah lembah bernama Badar." },
    19: { question: "Berapa jarak Badar dari Madinah?", options: ["50 km", "100 km", "150 km", "200 km"], correct: 2, explanation: "Lokasi Badar terletak kira-kira 150 km dari kota Madinah." },
    20: { question: "Nyatakan tarikh Perang Badar berlaku.", options: ["17 Ramadan", "1 Syawal", "10 Zulhijjah", "1 Muharram"], correct: 0, explanation: "Perang Badar berlaku pada tarikh yang sangat signifikan iaitu 17 Ramadan tahun ke-2 Hijrah." },
    21: { question: "Bagaimanakah peperangan dimulakan?", options: ["Serangan mengejut", "Memanah dari jauh", "Cabar-mencabar antara panglima", "Pengepungan kubu"], correct: 2, explanation: "Mengikut tradisi perang Arab, ia dimulakan dengan pertarungan satu lawan satu antara panglima." },
    22: { question: "Siapakah wakil Islam yang berlawan dengan Utbah bin Rabi’ah?", options: ["Hamzah bin Abd Mutalib", "Ali bin Abi Talib", "Ubaidah bin al-Harith", "Saad bin Abi Waqas"], correct: 2, explanation: "Ubaidah bin al-Harith, seorang pahlawan veteran, menyahut cabaran Utbah." },
    23: { question: "Siapakah lawan Hamzah bin Abd Mutalib?", options: ["Utbah bin Rabi’ah", "Syaibah bin Rabi’ah", "Al-Walid bin Utbah", "Abu Jahal"], correct: 1, explanation: "Hamzah 'Singa Allah' berhadapan dengan Syaibah bin Rabi’ah." },
    24: { question: "Siapakah lawan Ali bin Abi Talib?", options: ["Syaibah bin Rabi’ah", "Abu Jahal", "Umayyah bin Khalaf", "Al-Walid bin Utbah"], correct: 3, explanation: "Pahlawan muda Ali bin Abi Talib melawan Al-Walid bin Utbah." },
    25: { question: "Apakah hasil perlawanan panglima perang tersebut?", options: ["Semua pahlawan Islam tewas", "Berakhir seri", "Semua pahlawan musuh tewas", "Mereka berdamai"], correct: 2, explanation: "Dengan izin Allah, ketiga-tiga pahlawan Islam berjaya menewaskan musuh masing-masing." },
    26: { question: "Apakah keadaan peperangan selepas itu?", options: ["Sangat sengit", "Tentera Islam berundur", "Tentera musyrikin lari", "Berdamai serta-merta"], correct: 0, explanation: "Selepas pertarungan pembukaan, pertempuran besar yang sangat sengit pun meletus." },
    27: { question: "Pihak manakah yang kalah teruk?", options: ["Tentera Islam", "Tiada yang kalah", "Kedua-dua pihak", "Tentera musyrikin"], correct: 3, explanation: "Walaupun jumlah mereka lebih besar, tentera musyrikin mengalami kekalahan yang teruk." },
    28: { question: "Berapa tentera musyrikin terbunuh?", options: ["30 orang", "50 orang", "70 orang", "100 orang"], correct: 2, explanation: "Seramai 70 orang pembesar dan pahlawan Quraisy terbunuh dalam peperangan ini." },
    29: { question: "Siapakah pemimpin musyrikin yang terbunuh?", options: ["Abu Sufyan", "Abu Jahal", "Abu Lahab", "Khalid al-Walid"], correct: 1, explanation: "Abu Jahal, Firaun umat ini, adalah antara pemimpin utama Quraisy yang terbunuh." },
    30: { question: "Berapa tentera Islam yang syahid?", options: ["14 orang", "33 orang", "50 orang", "70 orang"], correct: 0, explanation: "Seramai 14 orang sahabat telah gugur syahid dalam mempertahankan Islam." }
};

const uhudQuizDatabase: QuizDatabase = {
    1: { question: "Mengapakah tentera musyrikin Mekah ingin membalas dendam terhadap orang Islam?", options: ["Kerana kekalahan mereka dalam Perang Badar", "Isu perebutan sumber air", "Perbalahan peribadi", "Perjanjian yang dimungkiri"], correct: 0, explanation: "Kekalahan di Badar merupakan satu tamparan hebat kepada ego dan maruah kaum musyrikin Mekah, menyebabkan mereka ingin membalas dendam." },
    2: { question: "Bilakah tentera musyrikin mula mempersiapkan pasukan untuk menyerang Madinah?", options: ["Pada awal tahun kedua Hijrah", "Pada akhir tahun kedua Hijrah", "Pada awal tahun ketiga Hijrah", "Pada pertengahan tahun ketiga Hijrah"], correct: 1, explanation: "Sejurus selepas Perang Badar, mereka mula merancang dan mengumpul kekuatan untuk serangan balas pada akhir tahun ke-2 Hijrah." },
    3: { question: "Berapakah jumlah tentera musyrikin yang disiapkan untuk Perang Uhud?", options: ["1,000 orang", "2,000 orang", "3,000 orang", "5,000 orang"], correct: 2, explanation: "Kaum musyrikin membawa tentera seramai 3,000 orang, tiga kali ganda lebih ramai berbanding tentera mereka di Badar." },
    4: { question: "Siapakah ketua tentera musyrikin dalam Perang Uhud?", options: ["Abu Jahal", "Khalid bin Al-Walid", "Ikrimah bin Abu Jahal", "Abu Sufyan"], correct: 3, explanation: "Selepas kematian Abu Jahal di Badar, Abu Sufyan mengambil alih sebagai ketua panglima tentera musyrikin." },
    5: { question: "Bilakah tentera musyrikin bergerak ke Madinah?", options: ["Pada bulan Ramadan tahun ketiga Hijrah", "Pada bulan Syawal tahun ketiga Hijrah", "Pada bulan Zulhijjah tahun ketiga Hijrah", "Pada bulan Muharram tahun keempat Hijrah"], correct: 1, explanation: "Mereka memilih bulan Syawal pada tahun ke-3 Hijrah untuk melancarkan serangan mereka ke atas Madinah." },
    6: { question: "Tahun ketiga Hijrah bersamaan dengan tahun Masihi berapa?", options: ["624 Masihi", "625 Masihi", "626 Masihi", "627 Masihi"], correct: 1, explanation: "Perang Uhud berlaku pada sekitar tahun 625 Masihi." },
    7: { question: "Apakah kaum yang membentuk tentera musyrikin dalam Perang Uhud?", options: ["Kaum Quraisy, Tihamah dan Kinanah", "Kaum Aus dan Khazraj", "Bani Nadhir dan Bani Quraizah", "Rom dan Parsi"], correct: 0, explanation: "Tentera musyrikin terdiri daripada gabungan kaum Quraisy serta sekutu mereka iaitu Tihamah dan Kinanah." },
    8: { question: "Siapakah golongan hamba yang turut serta dalam tentera musyrikin?", options: ["Hamba-hamba dari Parsi", "Hamba-hamba dalam kalangan orang Habsyah", "Hamba-hamba dari Rom", "Hamba-hamba dari Yaman"], correct: 1, explanation: "Mereka turut membawa hamba-hamba dari Habsyah yang mahir dalam peperangan." },
    9: { question: "Berapakah jumlah unta yang digunakan oleh tentera musyrikin untuk membawa bekalan?", options: ["1,000 ekor unta", "2,000 ekor unta", "3,000 ekor unta", "4,000 ekor unta"], correct: 2, explanation: "Sebanyak 3,000 ekor unta digunakan untuk logistik dan membawa bekalan perang yang besar." },
    10: { question: "Berapakah jumlah tentera berkuda pihak musyrikin?", options: ["100 orang", "200 orang", "300 orang", "500 orang"], correct: 1, explanation: "Pasukan berkuda mereka yang kuat berjumlah 200 orang, satu kelebihan besar berbanding tentera Islam." },
    11: { question: "Berapakah jumlah tentera musyrikin yang memakai baju besi?", options: ["300 orang", "500 orang", "700 orang", "1,000 orang"], correct: 2, explanation: "Seramai 700 orang tentera mereka lengkap memakai baju besi, menunjukkan persiapan rapi mereka." },
    12: { question: "Apakah peranan kumpulan wanita dalam tentera musyrikin?", options: ["Merawat yang cedera", "Memasak makanan", "Menyanyikan lagu-lagu semangat", "Menjadi pengintip"], correct: 2, explanation: "Kumpulan wanita yang diketuai oleh Hindun binti Utbah bertugas menaikkan semangat tentera dengan nyanyian dan syair." },
    13: { question: "Siapakah yang menyampaikan berita kedatangan tentera musyrikin kepada Nabi Muhammad SAW?", options: ["Abu Sufyan", "Seorang pengembara", "Al-Abbas", "Seorang munafik"], correct: 2, explanation: "Bapa saudara Nabi, Al-Abbas bin Abdul Mutalib, yang masih di Mekah telah menghantar utusan rahsia untuk memaklumkan berita tersebut." },
    14: { question: "Apakah tindakan Nabi Muhammad SAW selepas menerima berita tersebut?", options: ["Terus menyerang", "Meminta bantuan", "Mengadakan mesyuarat tergempar", "Bersembunyi"], correct: 2, explanation: "Nabi SAW segera mengadakan mesyuarat dengan para sahabat untuk membincangkan strategi pertahanan." },
    15: { question: "Apakah cadangan golongan muda dalam mesyuarat tersebut?", options: ["Menentang musuh di luar Madinah", "Berperang di dalam kota", "Menyerah diri", "Membuat perjanjian damai"], correct: 0, explanation: "Para sahabat muda yang bersemangat ingin berhadapan dengan musuh secara terbuka di luar kota Madinah." },
    16: { question: "Apakah cadangan golongan tua dalam mesyuarat tersebut?", options: ["Menyerang pada waktu malam", "Meminta bantuan luar", "Berkubu di dalam kota Madinah", "Melarikan diri"], correct: 2, explanation: "Golongan yang lebih berpengalaman mencadangkan agar bertahan di dalam kota dan menggunakan kelebihan benteng Madinah." },
    17: { question: "Apakah keputusan akhir Nabi Muhammad SAW?", options: ["Mengikut cadangan golongan tua", "Tidak membuat keputusan", "Berhadapan dengan musuh di luar Madinah", "Menunggu wahyu"], correct: 2, explanation: "Walaupun pada mulanya baginda cenderung untuk bertahan di dalam kota, Nabi SAW menghormati suara majoriti (golongan muda) dan memutuskan untuk keluar." },
    18: { question: "Berapakah jumlah tentera Islam yang dibentuk oleh Nabi Muhammad SAW?", options: ["700 orang", "1,000 orang", "1,500 orang", "2,000 orang"], correct: 1, explanation: "Pada mulanya, seramai 1,000 orang tentera Islam telah dikumpulkan untuk menghadapi musuh." },
    19: { question: "Berapakah jumlah tentera Islam yang memakai baju besi?", options: ["100 orang", "200 orang", "300 orang", "400 orang"], correct: 3, explanation: "Di kalangan tentera Islam, seramai 400 orang yang memakai baju besi, menunjukkan kekurangan kelengkapan berbanding musuh." },
    20: { question: "Berapakah jumlah pasukan pemanah tentera Islam?", options: ["20 orang", "30 orang", "50 orang", "100 orang"], correct: 2, explanation: "Satu pasukan khas seramai 50 orang pemanah handal telah dibentuk dan diletakkan di atas Bukit Uhud." },
    21: { question: "Siapakah ketua pasukan pemanah tentera Islam?", options: ["Saad bin Abi Waqas", "Abdullah bin Jubair", "Zubair Al-Awwam", "Qatadah bin an-Nu'man"], correct: 1, explanation: "Abdullah bin Jubair dilantik sebagai ketua pasukan pemanah dengan arahan jelas untuk tidak meninggalkan posisi walau apa pun terjadi." },
    22: { question: "Siapakah ketua munafik yang membawa 300 tentera Islam berpatah balik?", options: ["Abdullah bin Ubay bin Salul", "Abu Amir al-Rahib", "Mirba' bin Qaizi", "Ka'ab bin al-Asyraf"], correct: 0, explanation: "Abdullah bin Ubay bin Salul, ketua golongan munafik, telah menghasut 300 orang untuk berpatah balik ke Madinah." },
    23: { question: "Apakah alasan mereka berpatah balik?", options: ["Kekurangan senjata", "Keluarga sakit", "Menyangka peperangan tidak akan berlaku", "Tidak bersetuju dengan strategi"], correct: 2, explanation: "Alasan mereka adalah cadangan mereka untuk berperang di dalam kota tidak diterima, walaupun niat sebenar mereka adalah untuk memecahbelahkan pasukan Islam." },
    24: { question: "Berapakah jumlah tentera Islam yang terus berjuang?", options: ["500 orang", "600 orang", "700 orang", "800 orang"], correct: 2, explanation: "Selepas pengunduran golongan munafik, baki tentera Islam yang setia tinggal seramai 700 orang." },
    25: { question: "Bilakah Perang Uhud berlaku?", options: ["Hari Jumaat, 7 Syawal, tahun ketiga Hijrah", "Hari Sabtu, 17 Syawal, tahun ketiga Hijrah", "Hari Ahad, 27 Ramadan, tahun ketiga Hijrah", "Hari Isnin, 1 Muharram, tahun ketiga Hijrah"], correct: 1, explanation: "Pertempuran Uhud berlaku pada hari Sabtu, 17 Syawal, tahun ke-3 Hijrah." },
    26: { question: "Siapakah pahlawan Islam yang menewaskan Tolhah bin Abu Tolhah?", options: ["Ali bin Abi Talib", "Hamzah bin Abdul Mutalib", "Al-Zubir Al-Awwam", "Saad bin Abi Waqas"], correct: 2, explanation: "Al-Zubir Al-Awwam, seorang pahlawan Islam yang hebat, telah menewaskan pembawa bendera musyrikin, Tolhah bin Abu Tolhah." },
    27: { question: "Siapakah pahlawan Islam yang menewaskan Uthman bin Abu Tolhah?", options: ["Saidina Hamzah bin Abdul Mutalib", "Ali bin Abi Talib", "Abu Dujanah", "Umar Al-Khattab"], correct: 0, explanation: "Saidina Hamzah, 'Singa Allah', telah menewaskan pembawa bendera musyrikin yang lain, iaitu Uthman bin Abu Tolhah." },
    28: { question: "Apakah kesalahan pasukan pemanah yang menyebabkan kekalahan tentera Islam?", options: ["Tertidur semasa bertugas", "Kehabisan anak panah", "Meninggalkan posisi untuk mengambil harta rampasan perang", "Salah mentafsir arahan"], correct: 2, explanation: "Apabila melihat tentera musyrikin mula berundur, sebahagian besar pasukan pemanah telah meninggalkan posisi mereka untuk mengutip harta rampasan perang, mengingkari arahan Nabi." },
    29: { question: "Siapakah panglima musyrikin yang menyerang dari belakang bukit?", options: ["Abu Sufyan", "Ikrimah bin Abu Jahal", "Safwan bin Umayyah", "Khalid bin Al-Walid"], correct: 3, explanation: "Khalid bin Al-Walid, yang ketika itu belum memeluk Islam, mengambil kesempatan ini untuk memimpin pasukan berkudanya menyerang tentera Islam dari arah belakang." },
    30: { question: "Apakah pengajaran utama daripada Perang Uhud?", options: ["Kekuatan senjata menjamin kemenangan", "Jumlah tentera yang ramai adalah kunci", "Melanggar arahan ketua dan cinta kepada dunia membawa musibah", "Berperang pada bulan Syawal membawa sial"], correct: 2, explanation: "Perang Uhud menjadi pengajaran besar tentang akibat mengingkari arahan pemimpin dan sifat tamak terhadap harta dunia." }
};


const khandakQuizDatabase: QuizDatabase = {
    1: { question: "Apakah perasaan kaum musyrikin Makkah selepas Perang Uhud?", options: ["Angkuh", "Sedih", "Takut", "Menyesal"], correct: 0, explanation: "Selepas Perang Uhud, kaum musyrikin Makkah merasa angkuh dan sombong kerana merasakan mereka telah berjaya mengalahkan tentera Islam." },
    2: { question: "Apakah tujuan utama kaum musyrikin Makkah selepas Perang Uhud?", options: ["Berdamai dengan Madinah", "Menguasai laluan dagang", "Memerangi orang Islam di Madinah", "Mencari sekutu baru"], correct: 2, explanation: "Tujuan utama mereka adalah untuk menghapuskan terus pengaruh Islam dengan menyerang pusatnya di Madinah." },
    3: { question: "Mengapakah kaum Yahudi Bani Nadhir tidak puas hati terhadap orang Islam?", options: ["Isu perniagaan", "Isu sempadan", "Kerana diusir dari Madinah akibat pengkhianatan", "Perbezaan agama"], correct: 2, explanation: "Mereka diusir kerana telah mengkhianati Piagam Madinah dan merancang untuk membunuh Nabi Muhammad SAW." },
    4: { question: "Apakah tindakan kaum Yahudi Bani Nadhir selepas diusir dari Madinah?", options: ["Menyerah diri", "Berpindah ke Habsyah", "Menunggu masa untuk membalas dendam", "Meminta maaf"], correct: 2, explanation: "Mereka menyimpan dendam dan mula menghasut kaum musyrikin Makkah dan puak-puak lain untuk menyerang Madinah." },
    5: { question: "Siapakah yang bergabung membentuk tentera Ahzab?", options: ["Rom dan Parsi", "Musyrikin Makkah dan Habsyah", "Kaum musyrikin Makkah dan Yahudi Bani Nadhir", "Islam dan Yahudi"], correct: 2, explanation: "Tentera Ahzab (bersekutu) terdiri daripada gabungan utama kaum musyrikin Makkah, kaum Yahudi Bani Nadhir, dan beberapa puak Arab lain." },
    6: { question: "Berapakah jumlah tentera pasukan Ahzab?", options: ["3,000 orang", "5,000 orang", "10,000 orang", "15,000 orang"], correct: 2, explanation: "Pasukan Ahzab merupakan gabungan tentera yang sangat besar pada waktu itu, berjumlah sekitar 10,000 orang." },
    7: { question: "Siapakah ketua tentera Ahzab?", options: ["Abu Jahal", "Khalid al-Walid", "Abu Sufyan bin Harb", "Ikrimah bin Abu Jahal"], correct: 2, explanation: "Abu Sufyan bin Harb adalah pemimpin tertinggi bagi keseluruhan tentera bersekutu (Ahzab)." },
    8: { question: "Mengapakah Perang Khandak juga dikenali sebagai Perang Ahzab?", options: ["Kerana berlaku pada bulan Rejab", "Kerana strategi parit", "Gabungan beberapa puak musyrikin", "Kerana pemimpinnya Abu Sufyan"], correct: 2, explanation: "Ia dikenali sebagai Perang Ahzab (الحزب) yang bermaksud 'puak-puak' atau 'sekutu', merujuk kepada gabungan tentera musuh." },
    9: { question: "Apakah langkah pertama Nabi Muhammad SAW sebelum peperangan bermula?", options: ["Menyediakan senjata", "Menyerang dahulu", "Bermesyuarat dengan para sahabat", "Bersembunyi di dalam kota"], correct: 2, explanation: "Nabi SAW sentiasa mengamalkan prinsip syura (mesyuarat) untuk mendapatkan pandangan terbaik daripada para sahabat." },
    10: { question: "Siapakah sahabat yang mencadangkan strategi menggali parit?", options: ["Abu Bakar As-Siddiq", "Umar Al-Khattab", "Ali bin Abi Talib", "Salman Al-Farisi"], correct: 3, explanation: "Salman Al-Farisi, yang berasal dari Parsi, mencadangkan strategi ini kerana ia belum pernah digunakan dalam peperangan di Tanah Arab." },
    11: { question: "Apakah tujuan utama menggali parit?", options: ["Sebagai sumber air", "Menghalang musuh masuk ke Madinah", "Perangkap kuda musuh", "Sempadan kota Madinah"], correct: 1, explanation: "Parit (khandaq) digali sebagai benteng pertahanan untuk menghalang kemaraan tentera berkuda dan infantri musuh." },
    12: { question: "Di manakah parit digali?", options: ["Selatan Madinah", "Timur Madinah", "Barat Madinah", "Utara Madinah"], correct: 3, explanation: "Parit digali di kawasan utara Madinah yang terbuka dan terdedah kepada serangan." },
    13: { question: "Mengapakah parit digali di utara Madinah?", options: ["Tanahnya lembut", "Dekat dengan sumber air", "Arah paling mudah diserang musuh", "Mengikut arah angin"], correct: 2, explanation: "Arah lain dilindungi oleh kawasan perumahan padat, kebun tamar, dan kawasan berbatu yang sukar dilalui tentera." },
    14: { question: "Bilakah Perang Khandak berlaku?", options: ["Tahun 2 Hijrah", "Tahun 3 Hijrah", "Tahun 5 Hijrah", "Tahun 8 Hijrah"], correct: 2, explanation: "Perang Khandak berlaku pada tahun ke-5 Hijrah, iaitu tiga tahun selepas Perang Badar." },
    15: { question: "Perang Khandak berlaku pada bulan apa?", options: ["Ramadan", "Syawal", "Zulkaedah", "Zulhijjah"], correct: 1, explanation: "Pengepungan Madinah oleh tentera Ahzab berlaku dalam bulan Syawal." },
    16: { question: "Tahun 5 Hijrah bersamaan dengan tahun Masihi berapa?", options: ["625 Masihi", "627 Masihi", "628 Masihi", "630 Masihi"], correct: 1, explanation: "Perang Khandak berlaku pada sekitar tahun 627 Masihi." },
    17: { question: "Berapakah jumlah tentera Islam dalam Perang Khandak?", options: ["1,000 orang", "3,000 orang", "7,000 orang", "10,000 orang"], correct: 1, explanation: "Tentera Islam berjumlah 3,000 orang, jauh lebih kecil berbanding tentera Ahzab." },
    18: { question: "Siapakah ketua tentera Islam dalam Perang Khandak?", options: ["Abu Bakar As-Siddiq", "Saad bin Muaz", "Nabi Muhammad SAW", "Hamzah bin Abdul Mutalib"], correct: 2, explanation: "Nabi Muhammad SAW sendiri yang memimpin tentera Islam dalam mempertahankan kota Madinah." },
    19: { question: "Siapakah pembawa bendera tentera Islam dari kalangan Muhajirin?", options: ["Umar Al-Khattab", "Ali bin Abi Talib", "Zaid bin Al-Harithah", "Abu Ubaidah Al-Jarrah"], correct: 2, explanation: "Zaid bin Al-Harithah, sahabat yang amat disayangi Nabi SAW, diberi penghormatan membawa bendera kaum Muhajirin." },
    20: { question: "Siapakah pembawa bendera tentera Islam dari kalangan Ansar?", options: ["Saad bin Ubadah", "Saad bin Muaz", "Usaid bin Hudhair", "Basyir bin Saad"], correct: 0, explanation: "Saad bin Ubadah, seorang pemimpin dari kaum Ansar, telah diamanahkan untuk membawa bendera mereka." },
    21: { question: "Bagaimanakah Allah SWT menolong tentera Islam dalam peperangan ini?", options: ["Menurunkan hujan batu", "Menurunkan wabak penyakit", "Menurunkan angin kencang", "Menurunkan api"], correct: 2, explanation: "Allah SWT menghantar bantuan dalam bentuk angin kencang yang sejuk pada waktu malam yang memporak-perandakan kem tentera musuh." },
    22: { question: "Apakah kesan angin kencang terhadap tentera musyrikin?", options: ["Menyejukkan suasana", "Khemah tentera musyrikin berterbangan", "Memadamkan unggun api sahaja", "Tiada kesan besar"], correct: 1, explanation: "Angin yang sangat kencang telah merosakkan dan menerbangkan khemah-khemah mereka, menyebabkan keadaan menjadi kelam-kabut." },
    23: { question: "Apakah yang berlaku kepada periuk belanga tentera musyrikin?", options: ["Penuh dengan air hujan", "Dicuri oleh tentera Islam", "Bertaburan", "Menjadi lebih panas"], correct: 2, explanation: "Angin kencang itu juga menterbalikkan dan menaburkan periuk-periuk makanan mereka, menyebabkan mereka kelaparan." },
    24: { question: "Apakah kesan debu dan batu terhadap tentera musyrikin?", options: ["Menyuburkan tanah", "Mereka tidak terkesan", "Mereka lari menyelamatkan diri", "Menjadi bahan binaan"], correct: 2, explanation: "Angin tersebut membawa debu dan batu-batu kecil yang menyakitkan, menyebabkan mereka panik dan lari meninggalkan medan perang." },
    25: { question: "Siapakah pemenang Perang Khandak?", options: ["Tiada pemenang", "Tentera Ahzab", "Tentera Islam", "Berdamai"], correct: 2, explanation: "Dengan pertolongan Allah dan strategi yang bijak, tentera Islam berjaya mempertahankan Madinah dan tentera Ahzab berundur dengan kerugian." },
    26: { question: "Siapakah antara panglima tentera kafir yang terbunuh?", options: ["Abu Sufyan", "Khalid al-Walid", "Manbah bin Abdul Abdari", "Uthman bin Talhah"], correct: 2, explanation: "Manbah bin Abdul Abdari adalah salah seorang panglima Quraisy yang terbunuh dalam pertempuran." },
    27: { question: "Siapakah lagi panglima tentera kafir yang terbunuh?", options: ["Amru bin Abdu", "Ikrimah bin Abu Jahal", "Safwan bin Umayyah", "Suhail bin Amru"], correct: 0, explanation: "Amru bin Abdu Wudd, seorang pahlawan musyrikin yang terkenal, berjaya menyeberangi parit tetapi telah dibunuh oleh Ali bin Abi Talib." },
    28: { question: "Bagaimanakah Naufal bin Abdullah mati?", options: ["Dibunuh oleh Saad bin Muaz", "Terjatuh ke dalam parit dan patah leher", "Terkena panah sesat", "Mati kesejukan"], correct: 1, explanation: "Naufal bin Abdullah adalah antara tentera musyrikin yang terbunuh selepas terjatuh ke dalam parit semasa cuba menyeberanginya." },
    29: { question: "Berapakah jumlah tentera Islam yang gugur syahid?", options: ["Seorang", "Enam orang", "Empat belas orang", "Tiada"], correct: 1, explanation: "Hanya sekitar enam orang sahabat yang gugur syahid sepanjang tempoh pengepungan, menunjukkan keberkesanan strategi parit." },
    30: { question: "Apakah pengajaran utama daripada Perang Khandak?", options: ["Kepentingan kekayaan", "Kekuatan individu semata-mata", "Kepentingan strategi dan pertolongan Allah", "Perlunya berputus asa"], correct: 2, explanation: "Perang Khandak mengajar kita betapa pentingnya strategi yang bijak (menggali parit) dan keyakinan penuh terhadap pertolongan Allah SWT." }
};

export const quests: Record<string, QuestData> = {
    'badar': {
        id: 'badar',
        title: 'Sirah Quest: Perang Badar',
        quiz: badarQuizDatabase,
        maxSquares: 30,
    },
    'uhud': {
        id: 'uhud',
        title: 'Sirah Quest: Perang Uhud',
        quiz: uhudQuizDatabase,
        maxSquares: 30,
    },
    'khandak': {
        id: 'khandak',
        title: 'Sirah Quest: Perang Khandak',
        quiz: khandakQuizDatabase,
        maxSquares: 30,
    }
};

export const questOrder = ['badar', 'uhud', 'khandak'];

export const successMessages = [
    "🌟 Jawapan yang tepat! Allah memberkati ilmu yang bermanfaat.",
    "✨ Alhamdulillah! Teruskan semangat menuntut ilmu!",
    "🎉 MasyaAllah! Ilmu Sirah yang baik akan membawa keberkatan dunia akhirat.",
    "🌙 Subhanallah! Dengan ilmu yang betul, kita semakin dekat dengan Rasulullah SAW.",
    "⭐ Allahu a'lam! Semoga ilmu ini menjadi cahaya dalam hidup anda.",
    "🕌 Jazakallah khair! Menuntut ilmu adalah kewajipan setiap Muslim.",
    "🌸 Barakallah! Semoga menjadi hamba Allah yang berilmu dan bertakwa."
];

export const errorMessages = [
    "💪 Tidak mengapa, teruskan usaha! 'Barangsiapa bersungguh-sungguh, mereka akan mendapat petunjuk.'",
    "🌱 Sabar dan teruskan belajar! Rasulullah SAW bersabda: 'Menuntut ilmu adalah kewajipan setiap Muslim.'",
    "🤲 Jangan berputus asa! Allah SWT suka kepada hamba yang terus berusaha dalam kebaikan.",
    "📚 Ini adalah proses pembelajaran! 'Di atas setiap yang berilmu ada Yang Maha Mengetahui.'",
    "🌟 Teruskan semangat! Setiap kesilapan adalah tangga menuju kejayaan yang lebih besar.",
    "💎 Istighfar dan cuba lagi! Allah Maha Pengampun dan suka kepada hamba yang bertaubat.",
    "🌈 Jangan menyerah! 'Sesungguhnya bersama kesulitan itu ada kemudahan.'"
];