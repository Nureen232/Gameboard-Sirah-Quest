
// Using free sound effects from Pixabay for demonstration
const soundUrls = {
  click: 'https://cdn.pixabay.com/audio/2022/03/15/audio_24915d3106.mp3',
  dice: 'https://cdn.pixabay.com/audio/2021/08/04/audio_12b0c14262.mp3', // New dice sound
  correct: 'https://cdn.pixabay.com/audio/2022/11/21/audio_a25c102a24.mp3',
  incorrect: 'https://cdn.pixabay.com/audio/2022/03/24/audio_903784237f.mp3',
  achievement: 'https://cdn.pixabay.com/audio/2022/09/23/audio_a82a392231.mp3',
  backgroundMusic: 'https://cdn.pixabay.com/audio/2024/05/09/audio_96743b62f1.mp3', // New Epic Arabic background music
};

type SoundKeys = keyof typeof soundUrls;

const sounds: Record<SoundKeys, HTMLAudioElement> = {
    click: new Audio(soundUrls.click),
    dice: new Audio(soundUrls.dice),
    correct: new Audio(soundUrls.correct),
    incorrect: new Audio(soundUrls.incorrect),
    achievement: new Audio(soundUrls.achievement),
    backgroundMusic: new Audio(soundUrls.backgroundMusic),
};

// Configure background music
sounds.backgroundMusic.loop = true;
sounds.backgroundMusic.volume = 0.3; // Set a lower volume for background music

// Preload sounds for better performance
Object.values(sounds).forEach(sound => {
  sound.load();
});

let canPlay = false;
const enableAudio = () => {
    if (!canPlay) {
        canPlay = true;
        // Play a silent sound to unlock audio context on mobile browsers
        // This is a common trick to enable audio on user interaction
        const silentSound = new Audio("data:audio/mp3;base64,SUQzBAAAAAABEVRYWFgAAAAtAAADY29tbWVudABCaWdTb3VuZEJhbmsuY29tIC8gTG93ZXN0IFJhdGUgb2YgUmF0ZXM=");
        silentSound.play().catch(() => {});
    }
}

let isMuted = false;

const playSound = (sound: HTMLAudioElement) => {
  if (canPlay && !isMuted) {
    sound.currentTime = 0;
    sound.play().catch(e => console.error("Error playing sound:", e));
  }
};

const playMusic = () => {
    if (canPlay && !isMuted) {
        if (sounds.backgroundMusic.paused) {
            sounds.backgroundMusic.play().catch(e => console.error("Error playing music:", e));
        }
    }
};

const stopMusic = () => {
    sounds.backgroundMusic.pause();
    sounds.backgroundMusic.currentTime = 0;
};

const toggleMute = () => {
    isMuted = !isMuted;
    if (isMuted) {
        // Pause all sounds, but don't reset their time
        Object.values(sounds).forEach(sound => sound.pause());
    }
    // The App component will be responsible for resuming music if needed
    return isMuted;
};


export const soundManager = {
  enable: enableAudio,
  toggleMute: toggleMute,
  isMuted: () => isMuted,
  playDice: () => playSound(sounds.dice),
  playCorrect: () => playSound(sounds.correct),
  playIncorrect: () => playSound(sounds.incorrect),
  playAchievement: () => playSound(sounds.achievement),
  playClick: () => playSound(sounds.click),
  playMusic: playMusic,
  stopMusic: stopMusic,
};
