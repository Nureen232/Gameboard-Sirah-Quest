
import React, { useState, useCallback, useEffect } from 'react';
import { Player, Screen } from './types';
import PlayerSetup from './components/PlayerSetup';
import Instructions from './components/Instructions';
import Game from './components/Game';
import EndScreen from './components/EndScreen';
import { soundManager } from './sounds';
import { quests, questOrder } from './constants';

const resetPlayerForNextQuest = (player: Player): Player => ({
    ...player,
    position: 1,
    score: 0,
    correctAnswers: 0,
    questionsAnswered: 0,
    currentStreak: 0,
    maxStreak: 0,
    achievements: new Set<string>(),
    diceRolls: [],
    answerHistory: [],
    gameStartTime: Date.now(),
});


const App: React.FC = () => {
    const [screen, setScreen] = useState<Screen>('SETUP');
    const [players, setPlayers] = useState<Player[]>([]);
    const [finalScores, setFinalScores] = useState<Player[]>([]);
    const [isMuted, setIsMuted] = useState(soundManager.isMuted());
    const [currentQuestIndex, setCurrentQuestIndex] = useState(0);

    const currentQuest = quests[questOrder[currentQuestIndex]];
    const hasNextQuest = currentQuestIndex < questOrder.length - 1;

    // Effect to control background music based on the current screen
    useEffect(() => {
        if (screen === 'GAME' && !isMuted) {
            soundManager.playMusic();
        } else {
            soundManager.stopMusic();
        }
        // Stop music when component unmounts
        return () => {
            soundManager.stopMusic();
        };
    }, [screen, isMuted]);


    const handleSetupComplete = useCallback((newPlayers: Player[]) => {
        setPlayers(newPlayers);
        setCurrentQuestIndex(0);
        setScreen('INSTRUCTIONS');
    }, []);

    const handleStartGame = useCallback(() => {
        setScreen('GAME');
    }, []);

    const handleGameEnd = useCallback((scores: Player[]) => {
        setFinalScores(scores);
        setScreen('END');
    }, []);
    
    const handlePlayAgain = useCallback(() => {
        setPlayers([]);
        setFinalScores([]);
        setCurrentQuestIndex(0);
        setScreen('SETUP');
    }, []);

    const handleNextQuest = useCallback(() => {
        if (hasNextQuest) {
            setPlayers(prevPlayers => prevPlayers.map(resetPlayerForNextQuest));
            setCurrentQuestIndex(prev => prev + 1);
            setScreen('INSTRUCTIONS');
        }
    }, [hasNextQuest]);

    const handleToggleMute = () => {
        soundManager.enable(); // Ensure audio is enabled
        const muted = soundManager.toggleMute();
        setIsMuted(muted);
    };

    const renderScreen = () => {
        switch (screen) {
            case 'SETUP':
                return <PlayerSetup onSetupComplete={handleSetupComplete} />;
            case 'INSTRUCTIONS':
                return <Instructions onStartGame={handleStartGame} />;
            case 'GAME':
                return <Game players={players} onGameEnd={handleGameEnd} quest={currentQuest} />;
            case 'END':
                return <EndScreen 
                            finalScores={finalScores} 
                            onPlayAgain={handlePlayAgain} 
                            onNextQuest={handleNextQuest}
                            hasNextQuest={hasNextQuest}
                            questTitle={currentQuest.title}
                        />;
            default:
                return <PlayerSetup onSetupComplete={handleSetupComplete} />;
        }
    };

    return (
        <div className="bg-gradient-to-br from-[#DDB063] via-[#F4E4BC] to-[#E8D5A3] min-h-screen flex items-center justify-center p-4">
            <main className="w-full max-w-5xl mx-auto">
                {renderScreen()}
            </main>
            <button
                onClick={handleToggleMute}
                className="fixed bottom-4 right-4 w-12 h-12 bg-white/50 backdrop-blur-sm rounded-full flex items-center justify-center text-2xl border-2 border-[#2c5530] shadow-lg hover:bg-white/80 transition-all"
                aria-label={isMuted ? "Unmute sound" : "Mute sound"}
            >
                {isMuted ? '🔇' : '🔊'}
            </button>
        </div>
    );
};

export default App;