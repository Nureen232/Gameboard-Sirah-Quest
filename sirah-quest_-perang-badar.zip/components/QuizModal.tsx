
import React, { useState } from 'react';
import { Question } from '../types';
import { successMessages, errorMessages } from '../constants';
import { soundManager } from '../sounds';

interface QuizModalProps {
    question: Question;
    questionNumber: number;
    onAnswer: (isCorrect: boolean) => void;
    onClose: () => void;
}

const QuizModal: React.FC<QuizModalProps> = ({ question, questionNumber, onAnswer, onClose }) => {
    const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
    const [isAnswered, setIsAnswered] = useState(false);

    const handleSelectAnswer = (index: number) => {
        if (isAnswered) return;
        
        const isCorrect = index === question.correct;
        if (isCorrect) {
            soundManager.playCorrect();
        } else {
            soundManager.playIncorrect();
        }

        setSelectedAnswer(index);
        setIsAnswered(true);
        onAnswer(isCorrect);
    };

    const isCorrect = selectedAnswer === question.correct;

    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50 animate-fade-in">
            <div className="bg-white rounded-2xl p-6 md:p-8 shadow-2xl border-4 border-[#2c5530] max-w-2xl w-full text-center animate-zoom-in">
                <h2 className="text-xl md:text-2xl font-bold text-[#2c5530] mb-4">
                    Soalan {questionNumber}: {question.question}
                </h2>
                <div className="space-y-3 mb-5">
                    {question.options.map((option, index) => {
                        const isSelected = selectedAnswer === index;
                        const isCorrectOption = question.correct === index;
                        
                        let buttonClass = "w-full text-left p-4 rounded-lg border-2 border-[#2c5530] font-semibold transition-all duration-300";

                        if (isAnswered) {
                            if (isCorrectOption) {
                                buttonClass += " bg-green-200 border-green-500 ring-2 ring-green-500";
                            } else if (isSelected && !isCorrectOption) {
                                buttonClass += " bg-red-200 border-red-500 animate-shake";
                            } else {
                                buttonClass += " bg-gray-100 opacity-60";
                            }
                        } else {
                            buttonClass += " bg-gradient-to-br from-[#F4E4BC] to-[#E8D5A3] hover:bg-[#DDB063] hover:scale-[1.02]";
                        }

                        return (
                            <button key={index} onClick={() => handleSelectAnswer(index)} disabled={isAnswered} className={buttonClass}>
                                {option}
                            </button>
                        );
                    })}
                </div>

                {isAnswered && (
                    <div className="animate-fade-in">
                        <div className={`p-4 rounded-lg border-2 ${isCorrect ? 'bg-green-100 border-green-400' : 'bg-red-100 border-red-400'}`}>
                            <p className="font-bold text-lg mb-1">{isCorrect ? 'Betul!' : 'Kurang Tepat'}</p>
                            <p className="text-sm">{isCorrect ? successMessages[Math.floor(Math.random() * successMessages.length)] : errorMessages[Math.floor(Math.random() * errorMessages.length)]}</p>
                            <p className="text-sm mt-2"><strong>Penjelasan:</strong> {question.explanation}</p>
                        </div>
                        <button onClick={onClose} className="mt-5 w-full md:w-auto px-10 py-3 text-lg font-bold text-white bg-gradient-to-br from-[#2c5530] to-[#228b22] rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300">
                            Teruskan
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default QuizModal;
