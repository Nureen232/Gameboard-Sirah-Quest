
import React from 'react';
import { Player } from '../types';

interface BoardProps {
    players: Player[];
    currentPlayerId: number;
    maxSquares: number;
}

const getSquareColor = (number: number) => {
    const colors = [
        'bg-gradient-to-br from-sky-200 to-sky-300',      // blue
        'bg-gradient-to-br from-emerald-200 to-emerald-300',// green
        'bg-gradient-to-br from-amber-200 to-amber-300',    // yellow
        'bg-gradient-to-br from-orange-200 to-orange-300',// orange
        'bg-gradient-to-br from-pink-200 to-pink-300'    // pink
    ];
    return colors[number % 5];
};

const Board: React.FC<BoardProps> = ({ players, currentPlayerId, maxSquares }) => {
    const squares = [];
    const numRows = 3;
    for (let row = numRows - 1; row >= 0; row--) {
        const rowSquares = [];
        for (let col = 0; col < 10; col++) {
            const squareNumber = row % 2 === 0 ? (numRows - 1 - row) * 10 + col + 1 : (numRows - 1 - row) * 10 + (9 - col) + 1;
            
            if (squareNumber > maxSquares) {
                rowSquares.push(<div key={squareNumber} className="bg-transparent"></div>);
                continue;
            }

            let specialClass = '';
            let content: React.ReactNode = squareNumber;
            if (squareNumber === 1) {
                specialClass = 'bg-gradient-to-br from-lime-400 to-green-500 text-xs text-center';
                content = <>1<br/>🚀<br/><span className="font-semibold">Mula</span></>;
            } else if (squareNumber === maxSquares) {
                specialClass = 'bg-gradient-to-br from-yellow-400 to-orange-500 text-xs text-center';
                content = <>{maxSquares}<br/>🏆<br/><span className="font-semibold">Tamat</span></>;
            }

            const playersOnSquare = players.filter(p => p.position === squareNumber);

            rowSquares.push(
                <div key={squareNumber} id={`square-${squareNumber}`} className={`relative flex items-center justify-center font-bold text-sm text-[#2c5530] rounded-md transition-transform duration-300 hover:scale-105 ${getSquareColor(squareNumber)} ${specialClass}`}>
                    {content}
                    <div className="absolute bottom-0 left-0 right-0 flex justify-center items-end gap-1">
                        {playersOnSquare.map(p => (
                            <span key={p.id} className={`text-2xl md:text-3xl transition-all duration-500 ${p.id === currentPlayerId ? 'scale-125 animate-bounce' : 'opacity-80'}`} title={p.name} style={{filter: `drop-shadow(0 2px 2px rgba(0,0,0,0.4))`}}>
                                {p.character}
                            </span>
                        ))}
                    </div>
                </div>
            );
        }
        squares.push(...rowSquares);
    }

    return (
        <div className="grid grid-cols-10 grid-rows-3 gap-1 aspect-[10/3] bg-[#2c5530] p-2 rounded-xl shadow-inner relative">
            <div className="absolute top-0 left-0 text-3xl opacity-50">☪️</div>
            <div className="absolute top-0 right-0 text-3xl opacity-50">🕌</div>
            <div className="absolute bottom-0 left-0 text-3xl opacity-50">🌙</div>
            <div className="absolute bottom-0 right-0 text-3xl opacity-50">⭐</div>
            {squares}
        </div>
    );
};

export default Board;