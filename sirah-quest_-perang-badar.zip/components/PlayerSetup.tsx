
import React, { useState, useMemo } from 'react';
import { Player } from '../types';
import { PLAYER_CHARACTERS } from '../constants';
import { soundManager } from '../sounds';

interface PlayerSetupProps {
    onSetupComplete: (players: Player[]) => void;
}

const PlayerSetup: React.FC<PlayerSetupProps> = ({ onSetupComplete }) => {
    const [numPlayers, setNumPlayers] = useState<1 | 2>(1);
    const [player1Name, setPlayer1Name] = useState('');
    const [player2Name, setPlayer2Name] = useState('');

    const isFormValid = useMemo(() => {
        if (numPlayers === 1) {
            return player1Name.trim().length > 0;
        }
        return player1Name.trim().length > 0 && player2Name.trim().length > 0;
    }, [numPlayers, player1Name, player2Name]);

    const createPlayer = (id: number, name: string, character: string): Player => ({
        id,
        name,
        character,
        position: 1,
        score: 0,
        correctAnswers: 0,
        questionsAnswered: 0,
        currentStreak: 0,
        maxStreak: 0,
        achievements: new Set<string>(),
        diceRolls: [],
        answerHistory: [],
        gameStartTime: Date.now(),
    });

    const handleNumPlayerSelect = (num: 1 | 2) => {
        soundManager.enable();
        soundManager.playClick();
        setNumPlayers(num);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!isFormValid) return;
        soundManager.enable();
        soundManager.playClick();

        const players: Player[] = [
            createPlayer(1, player1Name.trim(), PLAYER_CHARACTERS[0]),
        ];
        if (numPlayers === 2) {
            players.push(createPlayer(2, player2Name.trim(), PLAYER_CHARACTERS[1]));
        }
        onSetupComplete(players);
    };
    
    const baseButtonClass = "px-8 py-4 text-lg font-bold rounded-lg border-4 transition-all duration-300 transform";
    const inactiveButtonClass = "bg-white/50 border-[#8c6d37] text-[#5c3d1f] hover:bg-white/80 hover:scale-105";
    const activeButtonClass = "bg-gradient-to-br from-[#FFD700] to-[#FFA500] border-[#2c5530] text-[#2c5530] scale-110 shadow-lg";

    return (
        <div className="bg-white rounded-2xl p-6 md:p-10 shadow-2xl border-4 border-[#2c5530] max-w-2xl mx-auto animate-fade-in-down">
            <h1 className="text-3xl md:text-4xl font-bold text-center text-[#2c5530] mb-2">
                🕌 Selamat Datang ke Sirah Quest!
            </h1>
            <p className="text-center text-gray-600 mb-8">Sediakan diri untuk pengembaraan Sirah.</p>
            
            <form onSubmit={handleSubmit}>
                <div className="mb-8">
                    <h2 className="text-xl font-semibold text-[#2c5530] mb-4 text-center">Pilih bilangan pengembara:</h2>
                    <div className="flex justify-center gap-6">
                        <button type="button" onClick={() => handleNumPlayerSelect(1)} className={`${baseButtonClass} ${numPlayers === 1 ? activeButtonClass : inactiveButtonClass}`}>
                            Seorang
                        </button>
                        <button type="button" onClick={() => handleNumPlayerSelect(2)} className={`${baseButtonClass} ${numPlayers === 2 ? activeButtonClass : inactiveButtonClass}`}>
                            Dua Orang
                        </button>
                    </div>
                </div>

                <div>
                    <h2 className="text-xl font-semibold text-[#2c5530] mb-4 text-center">Masukkan nama pengembara:</h2>
                    <div className="space-y-4">
                        <div className="relative">
                            <label htmlFor="player1" className="absolute -top-3 left-4 bg-white px-2 text-sm text-[#2c5530] font-semibold">Pengembara 1</label>
                            <input
                                type="text"
                                id="player1"
                                value={player1Name}
                                onChange={(e) => setPlayer1Name(e.target.value)}
                                maxLength={20}
                                placeholder="Cth: Panglima Soleh"
                                className="w-full px-4 py-3 border-2 border-[#2c5530] rounded-lg focus:ring-2 focus:ring-[#DDB063] focus:outline-none transition"
                            />
                        </div>
                        {numPlayers === 2 && (
                            <div className="relative animate-fade-in">
                                <label htmlFor="player2" className="absolute -top-3 left-4 bg-white px-2 text-sm text-[#2c5530] font-semibold">Pengembara 2</label>
                                <input
                                    type="text"
                                    id="player2"
                                    value={player2Name}
                                    onChange={(e) => setPlayer2Name(e.target.value)}
                                    maxLength={20}
                                    placeholder="Cth: Srikandi Fatimah"
                                    className="w-full px-4 py-3 border-2 border-[#2c5530] rounded-lg focus:ring-2 focus:ring-[#DDB063] focus:outline-none transition"
                                />
                            </div>
                        )}
                    </div>
                </div>

                <div className="mt-10">
                    <button
                        type="submit"
                        disabled={!isFormValid}
                        className="w-full py-4 text-xl font-bold text-white bg-gradient-to-br from-[#2c5530] to-[#228b22] rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none"
                    >
                        Teruskan
                    </button>
                </div>
            </form>
        </div>
    );
};

export default PlayerSetup;