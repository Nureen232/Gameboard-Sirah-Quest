
import React, { useState, useEffect, useCallback } from 'react';
import { Player, Question, Achievement, QuestData } from '../types';
import { STREAK_BADGE_THRESHOLD } from '../constants';
import { achievementsList } from '../achievements';
import Board from './Board';
import QuizModal from './QuizModal';
import BadgeNotification from './BadgeNotification';
import AchievementNotification from './AchievementNotification';
import { soundManager } from '../sounds';

interface GameProps {
    players: Player[];
    onGameEnd: (finalScores: Player[]) => void;
    quest: QuestData;
}

const Game: React.FC<GameProps> = ({ players, onGameEnd, quest }) => {
    const [playerStates, setPlayerStates] = useState<Player[]>(players);
    const [currentPlayerIndex, setCurrentPlayerIndex] = useState(0);
    const [diceValue, setDiceValue] = useState<number | null>(null);
    const [isRolling, setIsRolling] = useState(false);
    const [gameMessage, setGameMessage] = useState(`Giliran ${players[0].name}. Tekan dadu untuk mula!`);
    const [isQuizVisible, setIsQuizVisible] = useState(false);
    const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
    const [isBadgeVisible, setIsBadgeVisible] = useState(false);
    const [badgeMessage, setBadgeMessage] = useState('');

    const [achievementQueue, setAchievementQueue] = useState<Achievement[]>([]);
    const [currentAchievement, setCurrentAchievement] = useState<Achievement | null>(null);

    const checkAchievements = useCallback((updatedPlayers: Player[]) => {
        const player = updatedPlayers[currentPlayerIndex];
        const newAchievements: Achievement[] = [];
        
        achievementsList.forEach(ach => {
            if (!player.achievements.has(ach.id) && ach.condition(player, updatedPlayers)) {
                player.achievements.add(ach.id);
                newAchievements.push(ach);
            }
        });

        if (newAchievements.length > 0) {
            setAchievementQueue(prev => [...prev, ...newAchievements]);
        }
        return updatedPlayers;
    }, [currentPlayerIndex]);

    useEffect(() => {
        if (!currentAchievement && achievementQueue.length > 0) {
            const [next, ...rest] = achievementQueue;
            setCurrentAchievement(next);
            soundManager.playAchievement();
            setAchievementQueue(rest);
        }
    }, [achievementQueue, currentAchievement]);

    const handleAchievementClose = () => {
        setCurrentAchievement(null);
    };

    const handleDiceRoll = () => {
        if (isRolling || isQuizVisible) return;
        soundManager.playDice();
        setIsRolling(true);
        setDiceValue(null);

        setTimeout(() => {
            const roll = Math.floor(Math.random() * 6) + 1;
            setDiceValue(roll);
            setIsRolling(false);
            
            let updatedPlayers = playerStates.map((p, index) => 
                index === currentPlayerIndex ? { ...p, diceRolls: [...p.diceRolls, roll] } : p
            );
            updatedPlayers = checkAchievements(updatedPlayers);
            const currentPlayer = updatedPlayers[currentPlayerIndex];
            const newPosition = Math.min(currentPlayer.position + roll, quest.maxSquares);

            updatedPlayers = updatedPlayers.map((p, index) => 
                index === currentPlayerIndex ? { ...p, position: newPosition } : p
            );
             
            setPlayerStates(checkAchievements(updatedPlayers));

            setTimeout(() => {
                if (newPosition === quest.maxSquares) {
                    const finalPlayers = checkAchievements(updatedPlayers.map(p => {
                         if (p.id === currentPlayer.id) return { ...p, position: quest.maxSquares };
                         return p;
                    }));
                    onGameEnd(finalPlayers);
                } else {
                    setCurrentQuestion(quest.quiz[newPosition]);
                    setIsQuizVisible(true);
                }
            }, 1000);

        }, 1000);
    };

    const handleAnswer = useCallback((isCorrect: boolean) => {
        setPlayerStates(prev => {
            let updatedPlayers = prev.map((p, index) => {
                if (index === currentPlayerIndex) {
                    const newStreak = isCorrect ? p.currentStreak + 1 : 0;
                    const newMaxStreak = Math.max(p.maxStreak, newStreak);
                    const earnedPoints = isCorrect ? 10 + (p.currentStreak * 2) : 0;
                    
                    if (isCorrect && newStreak > 0 && newStreak % STREAK_BADGE_THRESHOLD === 0) {
                        setBadgeMessage(`Hebat ${p.name}! Anda mencapai ${newStreak} jawapan betul berturut-turut!`);
                        setIsBadgeVisible(true);
                    }

                    return {
                        ...p,
                        score: p.score + earnedPoints,
                        questionsAnswered: p.questionsAnswered + 1,
                        correctAnswers: p.correctAnswers + (isCorrect ? 1 : 0),
                        currentStreak: newStreak,
                        maxStreak: newMaxStreak,
                        answerHistory: [...p.answerHistory, isCorrect]
                    };
                }
                return p;
            });

            return checkAchievements(updatedPlayers);
        });
    }, [currentPlayerIndex, checkAchievements]);

    const handleQuizClose = () => {
        soundManager.playClick();
        setIsQuizVisible(false);
        setCurrentQuestion(null);
        setDiceValue(null);
        
        const nextPlayerIndex = (currentPlayerIndex + 1) % playerStates.length;
        setCurrentPlayerIndex(nextPlayerIndex);
        setGameMessage(`Giliran ${playerStates[nextPlayerIndex].name}. Tekan dadu!`);
    };

    const handleBadgeClose = () => setIsBadgeVisible(false);
    
    const currentPlayer = playerStates[currentPlayerIndex];

    return (
        <div className="bg-white rounded-2xl p-4 md:p-6 shadow-2xl border-4 border-[#2c5530] animate-fade-in">
            <h1 className="text-2xl md:text-3xl font-bold text-center text-[#2c5530] mb-4">
                🕌 {quest.title} <span className="text-sm align-top bg-gradient-to-br from-yellow-400 to-orange-500 text-[#2c5530] font-bold px-2 py-1 rounded-full border-2 border-[#2c5530]">V.12</span>
            </h1>

            {/* Controls */}
            <div className="grid grid-cols-3 gap-2 md:gap-4 items-center mb-4 p-4 bg-gradient-to-br from-[#F4E4BC] to-[#E8D5A3] rounded-lg border-2 border-[#2c5530]">
                {/* Player 1 Info */}
                <div className={`p-2 rounded-lg text-center transition-all duration-300 ${currentPlayerIndex === 0 ? 'bg-white/70 scale-105 shadow-lg' : 'opacity-70'}`}>
                    <h3 className="font-bold text-[#2c5530] truncate">{playerStates[0].name}</h3>
                    <p className="text-sm">Kedudukan: <span className="font-bold text-red-600">{playerStates[0].position}</span></p>
                    <p className="text-sm">Skor: <span className="font-bold text-blue-600">{playerStates[0].score}</span></p>
                </div>

                {/* Dice */}
                <div className="text-center">
                    <button onClick={handleDiceRoll} disabled={isRolling || isQuizVisible} className={`w-16 h-16 md:w-20 md:h-20 mx-auto bg-white border-4 border-[#2c5530] rounded-2xl flex items-center justify-center text-4xl font-bold text-[#2c5530] shadow-lg transition transform hover:scale-110 disabled:opacity-50 disabled:cursor-not-allowed ${isRolling ? 'animate-spin' : ''}`}>
                        {isRolling ? '...' : diceValue || '🎲'}
                    </button>
                    <p className="font-bold mt-2 text-[#2c5530] text-sm md:text-base">{isRolling ? 'Membaling...' : diceValue ? `Anda dapat: ${diceValue}` : 'Tekan Dadu'}</p>
                </div>

                {/* Player 2 / Stats Info */}
                <div className={`p-2 rounded-lg text-center transition-all duration-300 ${playerStates.length > 1 ? (currentPlayerIndex === 1 ? 'bg-white/70 scale-105 shadow-lg' : 'opacity-70') : ''}`}>
                    {playerStates.length > 1 ? (
                         <>
                            <h3 className="font-bold text-[#2c5530] truncate">{playerStates[1].name}</h3>
                            <p className="text-sm">Kedudukan: <span className="font-bold text-red-600">{playerStates[1].position}</span></p>
                            <p className="text-sm">Skor: <span className="font-bold text-blue-600">{playerStates[1].score}</span></p>
                         </>
                    ) : (
                         <div className="text-center text-[#2c5530]">
                            <div className="font-bold text-lg text-red-600">{currentPlayer.currentStreak} 🔥</div>
                            <div className="text-xs">Streak Semasa</div>
                        </div>
                    )}
                </div>
            </div>

            <Board players={playerStates} currentPlayerId={currentPlayer.id} maxSquares={quest.maxSquares} />

            <div className="text-center mt-4 p-3 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg border-2 border-[#2c5530] font-semibold text-[#2c5530] text-sm md:text-base">
                {gameMessage}
            </div>
            
            {isQuizVisible && currentQuestion && (
                <QuizModal 
                    question={currentQuestion}
                    questionNumber={currentPlayer.position}
                    onAnswer={handleAnswer}
                    onClose={handleQuizClose}
                />
            )}
            
            {isBadgeVisible && (
                <BadgeNotification 
                    message={badgeMessage}
                    onClose={handleBadgeClose}
                />
            )}

            {currentAchievement && (
                <AchievementNotification
                    achievement={currentAchievement}
                    onClose={handleAchievementClose}
                />
            )}
        </div>
    );
};

export default Game;