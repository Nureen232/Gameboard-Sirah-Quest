
import React, { useEffect, useMemo } from 'react';
import { Achievement, AchievementRarity } from '../types';

interface AchievementNotificationProps {
    achievement: Achievement;
    onClose: () => void;
}

const getRarityStyles = (rarity: AchievementRarity) => {
    switch (rarity) {
        case 'Common': return {
            gradient: 'from-green-400 to-emerald-600',
            glow: 'shadow-[0_0_15px_rgba(74,222,128,0.7)]',
            textColor: 'text-white',
            borderColor: 'border-green-200'
        };
        case 'Uncommon': return {
            gradient: 'from-sky-400 to-blue-600',
            glow: 'shadow-[0_0_15px_rgba(59,130,246,0.7)]',
            textColor: 'text-white',
            borderColor: 'border-sky-200'
        };
        case 'Rare': return {
            gradient: 'from-purple-400 to-indigo-600',
            glow: 'shadow-[0_0_20px_rgba(167,139,250,0.8)]',
            textColor: 'text-white',
            borderColor: 'border-purple-200'
        };
        case 'Epic': return {
            gradient: 'from-amber-400 to-yellow-500',
            glow: 'shadow-[0_0_25px_rgba(251,191,36,0.9)]',
            textColor: 'text-yellow-950',
            borderColor: 'border-amber-200'
        };
        case 'Legendary': return {
            gradient: 'from-orange-500 to-red-600',
            glow: 'shadow-[0_0_30px_rgba(239,68,68,1)]',
            textColor: 'text-white',
            borderColor: 'border-orange-300'
        };
        default: return {
            gradient: 'from-gray-400 to-gray-600',
            glow: 'shadow-lg',
            textColor: 'text-white',
            borderColor: 'border-gray-200'
        };
    }
};

const AchievementNotification: React.FC<AchievementNotificationProps> = ({ achievement, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClose();
        }, 5000); // Auto close after 5 seconds

        return () => clearTimeout(timer);
    }, [onClose]);
    
    const styles = useMemo(() => getRarityStyles(achievement.rarity), [achievement.rarity]);

    const categoryIcons: Record<string, string> = {
        'Permulaan': '🌱', 'Kemajuan': '📈', 'Streak': '🔥', 'Pengetahuan': '📚', 'Mata': '💰', 'Khas': '⭐', 'Tamat': '🏆'
    };

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-[100] animate-fade-in">
            <div 
                className={`relative bg-gradient-to-br ${styles.gradient} ${styles.glow} rounded-2xl p-6 shadow-2xl border-4 ${styles.borderColor} max-w-sm w-full text-center ${styles.textColor} transform animate-pop-in`}
                style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.4)' }}
            >
                <button onClick={onClose} className="absolute top-2 right-2 text-white/70 hover:text-white transition-colors h-6 w-6 flex items-center justify-center">&times;</button>
                <div className="text-5xl mb-3 animate-bounce">{categoryIcons[achievement.category] || '🎉'}</div>
                <p className="font-bold text-xs uppercase tracking-widest opacity-80">{achievement.rarity} Pencapaian!</p>
                <h2 className="text-2xl font-bold mb-2">{achievement.name}</h2>
                <p className="text-sm opacity-90">{achievement.description}</p>
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-3/4 h-4 bg-black/20 rounded-full blur-md"></div>
            </div>
            <style>{`
                @keyframes pop-in {
                    0% { transform: scale(0.5) rotate(-15deg); opacity: 0; }
                    70% { transform: scale(1.1) rotate(5deg); opacity: 1; }
                    100% { transform: scale(1) rotate(0deg); opacity: 1; }
                }
                .animate-pop-in {
                    animation: pop-in 0.5s cubic-bezier(0.68, -0.55, 0.27, 1.55) forwards;
                }
            `}</style>
        </div>
    );
};

export default AchievementNotification;
