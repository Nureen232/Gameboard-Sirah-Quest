
import React, { useEffect } from 'react';

interface BadgeNotificationProps {
    message: string;
    onClose: () => void;
}

const BadgeNotification: React.FC<BadgeNotificationProps> = ({ message, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClose();
        }, 4000); // Auto close after 4 seconds

        return () => clearTimeout(timer);
    }, [onClose]);

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-[100] animate-fade-in">
            <div 
                className="relative bg-gradient-to-br from-yellow-300 to-orange-500 rounded-2xl p-8 shadow-2xl border-4 border-white max-w-md w-full text-center text-[#2c5530] transform animate-pop-in"
                style={{
                    textShadow: '1px 1px 2px rgba(255,255,255,0.7)'
                }}
            >
                <button onClick={onClose} className="absolute top-2 right-2 text-white bg-[#2c5530]/50 rounded-full h-6 w-6 flex items-center justify-center">&times;</button>
                <div className="text-6xl mb-4 animate-bounce">🏅</div>
                <h2 className="text-2xl font-bold mb-2">Lencana Dicapai!</h2>
                <p className="text-lg font-semibold">{message}</p>
                 <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-3/4 h-4 bg-black/20 rounded-full blur-md"></div>
            </div>
            <style>{`
                @keyframes pop-in {
                    0% { transform: scale(0.5); opacity: 0; }
                    70% { transform: scale(1.1); opacity: 1; }
                    100% { transform: scale(1); opacity: 1; }
                }
                .animate-pop-in {
                    animation: pop-in 0.5s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default BadgeNotification;
