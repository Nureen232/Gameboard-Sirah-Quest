
import React from 'react';
import { Player } from '../types';
import { achievementsMap } from '../achievements';
import { AchievementRarity } from '../types';
import { soundManager } from '../sounds';

interface EndScreenProps {
    finalScores: Player[];
    onPlayAgain: () => void;
    onNextQuest: () => void;
    hasNextQuest: boolean;
    questTitle: string;
}

const getRarityClass = (rarity: AchievementRarity): string => {
    switch (rarity) {
        case 'Common': return 'bg-green-100 text-green-800 border-green-300';
        case 'Uncommon': return 'bg-blue-100 text-blue-800 border-blue-300';
        case 'Rare': return 'bg-purple-100 text-purple-800 border-purple-300';
        case 'Epic': return 'bg-yellow-100 text-yellow-800 border-yellow-400 glow-epic';
        case 'Legendary': return 'bg-orange-100 text-orange-800 border-orange-400 glow-legendary';
        default: return 'bg-gray-100 text-gray-800';
    }
};

const EndScreen: React.FC<EndScreenProps> = ({ finalScores, onPlayAgain, onNextQuest, hasNextQuest, questTitle }) => {
    const sortedPlayers = [...finalScores].sort((a, b) => b.score - a.score);
    const winner = sortedPlayers[0];
    const isTie = sortedPlayers.length > 1 && sortedPlayers[0].score === sortedPlayers[1].score;
    const shortQuestTitle = questTitle.split(': ')[1] || 'Sirah';

    let title = "🏆 Pengembaraan Tamat! 🏆";
    let message = `Tahniah ${winner.name}! Anda adalah Juara ${shortQuestTitle}!`;
    if (isTie) {
        title = "⚔️ Keputusan Seri! ⚔️";
        message = `Hebat! ${sortedPlayers.map(p => p.name).join(' dan ')} berkongsi kemenangan!`;
    } else if (sortedPlayers.length === 1) {
        message = `Tahniah ${winner.name}! Anda telah berjaya menyelesaikan pengembaraan!`;
    }

    const handlePlayAgainClick = () => {
        soundManager.playClick();
        onPlayAgain();
    };

    const handleNextQuestClick = () => {
        soundManager.playClick();
        onNextQuest();
    };
    
    return (
        <div className="bg-white rounded-2xl p-6 md:p-10 shadow-2xl border-4 border-[#2c5530] max-w-3xl mx-auto text-center animate-fade-in-down">
            <style>{`
                .glow-epic { box-shadow: 0 0 8px rgba(255, 215, 0, 0.7); }
                .glow-legendary { box-shadow: 0 0 12px rgba(255, 165, 0, 0.8); }
            `}</style>
            <h1 className="text-3xl md:text-4xl font-bold text-[#2c5530] mb-4">
                {title}
            </h1>
            <p className="text-lg text-gray-700 mb-8">{message}</p>

            <div className="space-y-6">
                {sortedPlayers.map((player, index) => {
                    const accuracy = player.questionsAnswered > 0 ? Math.round((player.correctAnswers / player.questionsAnswered) * 100) : 0;
                    const unlockedAchievements = Array.from(player.achievements).map(id => achievementsMap.get(id)).filter(Boolean);

                    return (
                        <div key={player.id} className={`p-4 rounded-lg border-2 ${index === 0 ? 'bg-gradient-to-br from-amber-200 to-yellow-300 border-[#2c5530]' : 'bg-gray-100 border-gray-300'}`}>
                            <h2 className="text-2xl font-bold text-[#2c5530] flex items-center justify-center gap-2">
                                {index === 0 && !isTie && '🏆'}
                                {isTie && '🏅'}
                                {player.name}
                            </h2>
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 my-4 text-gray-600">
                                <div>
                                    <p className="font-bold text-2xl text-blue-600">{player.score}</p>
                                    <p className="text-sm">Skor Akhir</p>
                                </div>
                                 <div>
                                    <p className="font-bold text-2xl text-green-600">{accuracy}%</p>
                                    <p className="text-sm">Ketepatan</p>
                                </div>
                                 <div>
                                    <p className="font-bold text-2xl text-red-600">{player.maxStreak} 🔥</p>
                                    <p className="text-sm">Streak Terbaik</p>
                                </div>
                                <div>
                                    <p className="font-bold text-2xl text-purple-600">{player.correctAnswers}/{player.questionsAnswered}</p>
                                    <p className="text-sm">Jawapan Betul</p>
                                </div>
                            </div>
                            {unlockedAchievements.length > 0 && (
                                <div>
                                    <h3 className="font-semibold text-left text-[#2c5530] mb-2">Pencapaian Dicapai:</h3>
                                    <div className="flex flex-wrap gap-2 justify-center">
                                        {unlockedAchievements.map(ach => ach && (
                                            <div key={ach.id} title={ach.description} className={`px-2 py-1 text-xs font-bold rounded-md border ${getRarityClass(ach.rarity)}`}>
                                                {ach.name}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>

            <div className="mt-10 flex flex-col md:flex-row gap-4 justify-center">
                <button
                    onClick={handlePlayAgainClick}
                    className="w-full md:w-auto px-12 py-4 text-xl font-bold text-[#2c5530] bg-gray-200 border-2 border-gray-400 rounded-lg shadow-lg hover:bg-gray-300 transform hover:-translate-y-1 transition-all duration-300"
                >
                    Bermain Semula
                </button>
                {hasNextQuest && (
                    <button
                        onClick={handleNextQuestClick}
                        className="w-full md:w-auto px-12 py-4 text-xl font-bold text-white bg-gradient-to-br from-[#2c5530] to-[#228b22] rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 animate-pulse"
                    >
                        Pengembaraan Seterusnya
                    </button>
                )}
            </div>
        </div>
    );
};

export default EndScreen;