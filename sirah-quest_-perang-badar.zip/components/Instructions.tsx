
import React from 'react';
import { soundManager } from '../sounds';

interface InstructionsProps {
    onStartGame: () => void;
}

const InstructionCard: React.FC<{ icon: string; title: string; children: React.ReactNode }> = ({ icon, title, children }) => (
    <div className="bg-gradient-to-br from-[#F4E4BC] to-[#E8D5A3] p-4 rounded-lg border-2 border-[#2c5530] shadow-md">
        <h3 className="text-lg font-bold text-[#2c5530] mb-2 flex items-center gap-2">
            <span className="text-2xl">{icon}</span>
            {title}
        </h3>
        <p className="text-gray-700 text-sm">{children}</p>
    </div>
);

const Instructions: React.FC<InstructionsProps> = ({ onStartGame }) => {
    const handleStartClick = () => {
        soundManager.enable();
        soundManager.playClick();
        onStartGame();
    };

    return (
        <div className="bg-white rounded-2xl p-6 md:p-10 shadow-2xl border-4 border-[#2c5530] max-w-3xl mx-auto animate-fade-in">
            <h1 className="text-3xl md:text-4xl font-bold text-center text-[#2c5530] mb-6">
                📚 Panduan Pengembaraan
            </h1>
            <div className="grid md:grid-cols-2 gap-4 mb-8">
                <InstructionCard icon="🎯" title="Objektif Permainan">
                    Jadilah pengembara pertama yang sampai ke petak 30 dengan menjawab soalan-soalan Sirah Perang dengan betul. Kumpul mata sebanyak mungkin!
                </InstructionCard>
                <InstructionCard icon="🎲" title="Cara Bermain">
                    Setiap giliran, tekan dadu untuk bergerak. Anda akan menjawab soalan di setiap petak. Jawapan betul memberi mata, jawapan salah tiada mata.
                </InstructionCard>
                <InstructionCard icon="🏅" title="Sistem Ganjaran">
                    Dapatkan mata, bina 'streak' untuk bonus, dan buka pencapaian istimewa dengan pelbagai tahap kesukaran untuk ganjaran tambahan!
                </InstructionCard>
                <InstructionCard icon="🕌" title="Nilai Spiritual">
                    Permainan ini bukan sekadar kuiz, tetapi satu cara untuk kita menghayati dan mengambil pengajaran daripada peristiwa agung Perang Nabawiyyah. Niatkan untuk menuntut ilmu.
                </InstructionCard>
            </div>
            <button
                onClick={handleStartClick}
                className="w-full py-4 text-xl font-bold text-white bg-gradient-to-br from-[#2c5530] to-[#228b22] rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300"
            >
                Mulakan Pengembaraan!
            </button>
        </div>
    );
};

export default Instructions;