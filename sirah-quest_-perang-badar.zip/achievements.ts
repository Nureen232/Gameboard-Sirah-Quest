
import { Achievement, Player } from './types';
import { quests, questOrder } from './constants'; // Assuming current quest can be inferred or passed

// A simplified way to get max_squares for achievements. 
// In a real app, you might pass the current quest context.
const MAX_SQUARES = 30; // Using a fixed value for now as passing context is complex here.

export const achievementsList: Achievement[] = [
    // Permulaan
    { id: 'start_journey', name: 'Langkah Pertama', description: 'Memulakan pengembaraan Sirah Badar.', category: 'Permulaan', rarity: 'Common', condition: (p) => p.questionsAnswered >= 1 },
    { id: 'roll_dice', name: 'Takdir Dadu', description: 'Membuat balingan dadu pertama.', category: 'Permulaan', rarity: 'Common', condition: (p) => p.diceRolls.length > 0 },

    // Kemajuan
    { id: 'reach_10', name: 'Penjelajah Muda', description: 'Sampai ke petak 10.', category: 'Kemajuan', rarity: 'Common', condition: (p) => p.position >= 10 },
    { id: 'reach_20', name: 'Panglima Harapan', description: 'Melepasi petak 20.', category: 'Kemajuan', rarity: 'Uncommon', condition: (p) => p.position >= 20 },
    { id: 'reach_finish', name: 'Wira Pengembara', description: 'Berjaya menamatkan permainan.', category: 'Tamat', rarity: 'Rare', condition: (p) => p.position === MAX_SQUARES },

    // Streak
    { id: 'streak_3', name: 'Tiga Serangkai', description: '3 jawapan betul berturut-turut.', category: 'Streak', rarity: 'Common', condition: (p) => p.maxStreak >= 3 },
    { id: 'streak_5', name: 'Momentum Hebat', description: '5 jawapan betul berturut-turut.', category: 'Streak', rarity: 'Uncommon', condition: (p) => p.maxStreak >= 5 },
    { id: 'streak_10', name: 'Sempurna', description: '10 jawapan betul berturut-turut.', category: 'Streak', rarity: 'Epic', condition: (p) => p.maxStreak >= 10 },

    // Pengetahuan
    { id: 'accuracy_80', name: 'Cendekiawan', description: 'Ketepatan jawapan melebihi 80% (min 10 soalan).', category: 'Pengetahuan', rarity: 'Rare', condition: (p) => p.questionsAnswered >= 10 && (p.correctAnswers / p.questionsAnswered) >= 0.8 },
    { id: 'perfect_game', name: 'Permainan Sempurna', description: 'Ketepatan 100% sepanjang permainan (min 15 soalan).', category: 'Pengetahuan', rarity: 'Legendary', condition: (p) => p.position === MAX_SQUARES && p.questionsAnswered >= 15 && p.correctAnswers === p.questionsAnswered },

    // Mata
    { id: 'score_100', name: 'Pengumpul Mata', description: 'Mengumpul 100 mata.', category: 'Mata', rarity: 'Common', condition: (p) => p.score >= 100 },
    { id: 'score_200', name: 'Khazanah Ilmu', description: 'Mengumpul 200 mata.', category: 'Mata', rarity: 'Uncommon', condition: (p) => p.score >= 200 },
    { id: 'score_300', name: 'Hartawan Sirah', description: 'Mengumpul 300 mata.', category: 'Mata', rarity: 'Rare', condition: (p) => p.score >= 300 },
    
    // Khas
    { id: 'lucky_six', name: 'Bertuah Enam', description: 'Mendapat dadu nombor 6 sebanyak 3 kali.', category: 'Khas', rarity: 'Rare', condition: (p) => p.diceRolls.filter(d => d === 6).length >= 3 },
    { id: 'comeback_king', name: 'Raja Comeback', description: 'Dapat streak 5 selepas 3 jawapan salah berturut.', category: 'Khas', rarity: 'Epic', condition: (p) => {
        const historyStr = p.answerHistory.map(a => a ? 'T' : 'F').join('');
        return historyStr.includes('FFF'.padEnd(3 + 5, 'T'));
    }},
    { id: 'smart_start', name: 'Permulaan Bijak!', description: 'Menjadi pemain pertama menjawab soalan dengan betul.', category: 'Khas', rarity: 'Uncommon', condition: (p, allPlayers) => {
        const totalCorrect = allPlayers.reduce((sum, player) => sum + player.correctAnswers, 0);
        return p.correctAnswers > 0 && totalCorrect === 1;
    }},
    { id: 'speed_runner', name: 'Pelari Pantas', description: 'Menamatkan permainan bawah 15 minit.', category: 'Khas', rarity: 'Epic', condition: (p) => p.position === MAX_SQUARES && (Date.now() - p.gameStartTime) < 15 * 60 * 1000 },
    { id: 'underdog', name: 'Kemenangan Mengejut', description: 'Menang permainan walaupun pernah ketinggalan 50 mata.', category: 'Khas', rarity: 'Legendary', condition: (p, allPlayers) => {
        if (p.position !== MAX_SQUARES || allPlayers.length < 2) return false;
        const sorted = [...allPlayers].sort((a, b) => b.score - a.score);
        if (sorted[0].id !== p.id) return false; // Must be the winner
        // This is a simplified check. A full implementation would need score history.
        // We will assume for now that if the winner has a lower max streak than the loser, they might be an underdog.
        return sorted.some(otherPlayer => otherPlayer.id !== p.id && otherPlayer.score > 0 && p.maxStreak < otherPlayer.maxStreak);
    }},
    
    // Tamat
    { id: 'winner', name: 'Juara', description: 'Memenangi permainan (skor tertinggi).', category: 'Tamat', rarity: 'Epic', condition: (p, allPlayers) => {
        if (p.position !== MAX_SQUARES) return false;
        const maxScore = Math.max(...allPlayers.map(player => player.score));
        return p.score === maxScore;
    }},
    { id: 'tie_game', name: 'Setia Kawan', description: 'Menamatkan permainan dengan keputusan seri.', category: 'Tamat', rarity: 'Rare', condition: (p, allPlayers) => {
        if (p.position !== MAX_SQUARES || allPlayers.length < 2) return false;
        const sorted = [...allPlayers].sort((a,b) => b.score - a.score);
        return sorted[0].score === sorted[1].score;
    }},
    { id: 'solo_finish', name: 'Pengembara Solo', description: 'Menamatkan permainan seorang diri.', category: 'Tamat', rarity: 'Uncommon', condition: (p, allPlayers) => p.position === MAX_SQUARES && allPlayers.length === 1 },
];

export const achievementsMap = new Map(achievementsList.map(ach => [ach.id, ach]));