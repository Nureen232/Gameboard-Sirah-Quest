
export type Screen = 'SETUP' | 'INSTRUCTIONS' | 'GAME' | 'END';

export type AchievementRarity = 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary';
export type AchievementCategory = 'Permulaan' | 'Kemajuan' | 'Streak' | 'Pengetahuan' | 'Mata' | 'Khas' | 'Tamat';

export interface Achievement {
    id: string;
    name: string;
    description: string;
    category: AchievementCategory;
    rarity: AchievementRarity;
    condition: (player: Player, allPlayers?: Player[]) => boolean;
    progress?: (player: Player) => { current: number; target: number };
}

export interface Player {
    id: number;
    name: string;
    position: number;
    score: number;
    correctAnswers: number;
    questionsAnswered: number;
    currentStreak: number;
    maxStreak: number;
    character: string;
    // New fields for achievement tracking
    achievements: Set<string>;
    diceRolls: number[];
    answerHistory: boolean[];
    gameStartTime: number;
}

export interface Question {
    question: string;
    options: string[];
    correct: number;
    explanation: string;
}

export interface QuizDatabase {
    [key: number]: Question;
}

export interface QuestData {
    id: string;
    title: string;
    quiz: QuizDatabase;
    maxSquares: number;
}